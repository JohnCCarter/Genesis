"""
Services Package - TradingBot Backend

Detta paket innehåller alla affärslogik-tjänster.
"""
