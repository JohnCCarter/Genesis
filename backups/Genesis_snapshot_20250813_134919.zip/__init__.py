"""
REST API Package - TradingBot Backend

Detta paket innehåller alla REST API-relaterade moduler.
"""
