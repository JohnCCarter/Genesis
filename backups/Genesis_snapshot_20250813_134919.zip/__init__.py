"""
Config Package - TradingBot Backend

Detta paket innehåller alla konfigurationsmoduler.
"""

from .settings import Settings

__all__ = ["Settings"]
